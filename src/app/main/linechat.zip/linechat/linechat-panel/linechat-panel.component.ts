import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linechat-panel',
  templateUrl: './linechat-panel.component.html',
  styleUrls: ['./linechat-panel.component.scss']
})
export class LinechatPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
